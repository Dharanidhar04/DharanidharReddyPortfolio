import React from 'react';

export function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          About Me
        </h2>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-gray-600 leading-relaxed">
              I am an aspiring software engineer with a keen interest in web development, web designing, and UI/UX design. Based in Hyderabad, India, I'm focused on learning and improving my skills to secure a job in front-end development.
            </p>
            <p className="text-gray-600 leading-relaxed">
              My journey in web development started with a strong foundation in HTML and CSS, and I'm continuously expanding my knowledge in JavaScript and React.js. I'm passionate about creating user-friendly interfaces and solving real-world problems through code.
            </p>
            <div className="flex gap-4">
              <a
                href="https://github.com/Dharanidhar04"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-gray-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                GitHub
              </a>
              <a
                href="https://www.linkedin.com/in/dharanidharreddy2002/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                LinkedIn
              </a>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2072&q=80"
              alt="Coding workspace"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
}