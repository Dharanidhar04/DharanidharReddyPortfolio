import React from 'react';
import { ChevronDown } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-white pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 mb-6">
          Hi, I'm <span className="text-blue-600">Dharanidhar Reddy</span>
        </h1>
        <h2 className="text-xl sm:text-2xl md:text-3xl text-gray-600 mb-8">
          Front-End Developer & UI/UX Designer
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-12">
          A passionate Front-End Developer with a love for creating intuitive and responsive web designs.
        </p>
        <a
          href="#contact"
          className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
        >
          Get in Touch
        </a>
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown size={32} className="text-blue-600" />
        </div>
      </div>
    </section>
  );
}