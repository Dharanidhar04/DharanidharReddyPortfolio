import React from 'react';

export function Skills() {
  const skills = [
    { name: 'HTML', level: 'Intermediate', percentage: 75 },
    { name: 'CSS', level: 'Intermediate', percentage: 75 },
    { name: 'JavaScript', level: 'Basic', percentage: 50 },
    { name: 'React.js', level: 'Learning', percentage: 40 },
    { name: 'SQL', level: 'Intermediate', percentage: 70 },
    { name: 'UI/UX Design', level: 'Learning', percentage: 45 },
  ];

  const tools = ['Visual Studio Code', 'Figma', 'Git', 'GitHub'];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Skills & Expertise
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Technical Skills</h3>
            {skills.map((skill) => (
              <div key={skill.name} className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-700">{skill.name}</span>
                  <span className="text-gray-500">{skill.level}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
                    style={{ width: `${skill.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Tools & Technologies</h3>
            <div className="grid grid-cols-2 gap-4">
              {tools.map((tool) => (
                <div
                  key={tool}
                  className="bg-white p-4 rounded-lg shadow-sm border border-gray-100"
                >
                  <span className="text-gray-700">{tool}</span>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Certifications</h3>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                  <h4 className="font-medium text-gray-900">Front-End Web Development</h4>
                  <p className="text-gray-600">Codetech IT Solutions (2024)</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                  <h4 className="font-medium text-gray-900">Full Stack Java</h4>
                  <p className="text-gray-600">Teks Academy (2024)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}